<center>TD2 Exercise 6 et Exercise 7</center>

Ex6.<br>
1.<br>
$Performance = β_0 + β_1 * Taille$<br>

Coefficient<br>
$β_0 = 1.7312459 $
$β_1 = 0.342$
<p align = "center">
<img src="./Images/ex61.png" alt="ex6 part 1">
</p>
2.<br>

| Source de variation | Degrés de liberté | Somme des carrés | Moyenne des carrés |  $F_c$ |
|---------------------|:-----------------:|:----------------:|:------------------:|-------:|
| Régression          |         1         |     0.012823     |     0.0128225      | 12.711 |
| Résiduelle          |        18         |     0.018158     |     0.0010088      |        |
| Totale              |        19         |    0.0300981     |                    |        |

<p align = "center">
<img src="./Images/ex62.png" alt="ex6 part 2">
</p>
3.<br>

$α = 0.95$

Ex7.<br>
1.<br>


<p align = "center">
<img src="./Images/e71.png" alt="ex7 part 1">
</p>

2.<br>

$Calories = β_0 + β_1 * PopulAgri$<br>
Coefficient<br>
$β_0 = 3346.122$
$β_1 = -17.164$
<p align = "center">
<img src="./Images/e72.png" alt="ex7 part 2">
</p>

3.<br>
Tableau d'analyse de variance correspondant.


| Source de variation | Degrés de liberté | Somme des carrés | Moyenne des carrés |  $F_c$ |
|---------------------|:-----------------:|:----------------:|:------------------:|-------:|
| Régression          |         1         |     2045960      |      2045960       | 20.907 |
| Résiduelle          |         8         |      880756      |       97862        |        |
| Totale              |         9         |     10853523     |                    |        |

<p align = "center">
<img src="./Images/e73.png" alt="ex7 part 3">
</p>

4.<br>
Un intervalle de confiance à 95% est:<br>
<p align = "center">
<img src="./Images/e74.png" alt="ex7 part 4">
</p>

5.<br>

<p align = "center">
<img src="./Images/e75.png" alt="ex7 part 5">
</p>
